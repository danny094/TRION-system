#!/usr/bin/env python3
import json
import os
import sqlite3
from datetime import datetime, timezone


DB_PATH = os.environ.get("COMMANDER_DB_PATH", "/app/data/commander.db")
HOME_ROOT = "/home/trion"
MANIFEST_PATH = f"{HOME_ROOT}/.trion/home.json"
DEFAULT_WRITE_ROOTS = [
    f"{HOME_ROOT}/notes",
    f"{HOME_ROOT}/diary",
    f"{HOME_ROOT}/scratch",
    f"{HOME_ROOT}/workspace",
    f"{HOME_ROOT}/artifacts",
]
HOME_CAPABILITY_CLASSES = [
    "container_inventory",
    "container_inspect",
    "container_logs",
    "file_read",
    "file_list",
    "file_write",
    "file_append",
    "workspace_read",
    "workspace_write",
    "local_exec",
]
AVAILABLE_HOME_CAPABILITIES = [
    "container_inventory",
    "container_inspect",
    "container_logs",
]

TOOLS = [
    {
        "name": "container_list",
        "description": "List containers with stable v2 status fields.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    {
        "name": "container_inspect",
        "description": "Inspect one container with stable v2 detail fields including blueprint_id and home_scope.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "container_id": {"type": "string"},
                "container_name": {"type": "string"},
            },
            "anyOf": [{"required": ["container_id"]}, {"required": ["container_name"]}],
            "additionalProperties": False,
        },
    },
    {
        "name": "container_logs",
        "description": "Read bounded logs from one container.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "container_id": {"type": "string"},
                "container_name": {"type": "string"},
                "tail": {"type": "integer", "default": 200},
                "since": {"type": "string", "default": ""},
                "limit_chars": {"type": "integer", "default": 16000},
            },
            "anyOf": [{"required": ["container_id"]}, {"required": ["container_name"]}],
            "additionalProperties": False,
        },
    },
    {
        "name": "blueprint_list",
        "description": "List installed blueprints from the commander store.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    {
        "name": "blueprint_get",
        "description": "Get one blueprint with a stable v2 detail shape.",
        "inputSchema": {
            "type": "object",
            "properties": {"blueprint_id": {"type": "string"}},
            "required": ["blueprint_id"],
            "additionalProperties": False,
        },
    },
    {
        "name": "start_stopped_container",
        "description": "Start a stopped TRION-managed container.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "container_id": {"type": "string"},
                "container_name": {"type": "string"},
            },
            "anyOf": [{"required": ["container_id"]}, {"required": ["container_name"]}],
            "additionalProperties": False,
        },
    },
    {
        "name": "stop_container",
        "description": "Stop a running TRION-managed container.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "container_id": {"type": "string"},
                "container_name": {"type": "string"},
            },
            "anyOf": [{"required": ["container_id"]}, {"required": ["container_name"]}],
            "additionalProperties": False,
        },
    },
]


def error_result(code, message, retryable=False):
    return {
        "ok": False,
        "error": {"code": code, "message": message, "retryable": retryable},
    }


def get_docker_client():
    try:
        from docker import from_env

        return from_env()
    except Exception as exc:
        raise RuntimeError(str(exc)) from exc


def is_not_found(error):
    return error.__class__.__name__ == "NotFound"


def is_true(value):
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def is_home_container(labels):
    return is_true(labels.get("trion.home")) or str(labels.get("trion.role") or "").strip().lower() == "home"


def blueprint_id_from_labels(labels):
    return str(labels.get("trion.blueprint") or "").strip()


def parse_home_manifest(raw):
    try:
        parsed = json.loads(str(raw or "").strip())
    except Exception:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def read_home_manifest(container):
    try:
        result = container.exec_run(["cat", MANIFEST_PATH])
    except Exception:
        return {}
    exit_code = getattr(result, "exit_code", None)
    if exit_code is None or int(exit_code) != 0:
        return {}
    output = getattr(result, "output", b"")
    try:
        raw = output.decode("utf-8", errors="replace")
    except Exception:
        return {}
    return parse_home_manifest(raw)


def build_home_scope(labels, manifest):
    if not is_home_container(labels):
        return {}
    manifest = manifest if isinstance(manifest, dict) else {}
    roots = manifest.get("roots") if isinstance(manifest.get("roots"), dict) else {}
    rules = manifest.get("rules") if isinstance(manifest.get("rules"), dict) else {}
    allowed = [str(item) for item in list(rules.get("allowed_write_roots") or DEFAULT_WRITE_ROOTS) if str(item).strip()]
    available = list(AVAILABLE_HOME_CAPABILITIES)
    missing = [item for item in HOME_CAPABILITY_CLASSES if item not in available]
    verification_sources = ["container_inspect"] + (["home_manifest"] if manifest else [])
    return {
        "is_home": True,
        "home_id": str(manifest.get("home_id") or blueprint_id_from_labels(labels) or "trion-home"),
        "blueprint_id": str(manifest.get("blueprint_id") or blueprint_id_from_labels(labels) or "trion-home"),
        "owner_agent": str(manifest.get("owner_agent") or "trion"),
        "runtime_profile": str(labels.get("trion.profile") or manifest.get("runtime_profile") or "trion-home"),
        "home_root": str(roots.get("home") or HOME_ROOT),
        "manifest_path": MANIFEST_PATH,
        "manifest_readable": bool(manifest),
        "allowed_write_roots": allowed,
        "available_capability_classes": available,
        "missing_capability_classes": missing,
        "verification_sources": verification_sources,
    }


def managed_flags(labels):
    managed = is_true(labels.get("trion.managed")) or "trion.blueprint" in labels
    protected = is_true(labels.get("trion.protected")) or is_true(labels.get("trion.system"))
    actions_allowed = managed and not protected
    return managed, actions_allowed, protected


def created_at(container):
    raw = getattr(container, "attrs", {}).get("Created", "")
    if raw:
        return str(raw)
    return datetime.now(timezone.utc).isoformat()


def port_rows(container):
    ports = ((container.attrs or {}).get("NetworkSettings") or {}).get("Ports") or {}
    rows = []
    for container_port, host_bindings in ports.items():
        if not host_bindings:
            rows.append({"container": str(container_port), "host": "", "ip": ""})
            continue
        for binding in host_bindings:
            rows.append(
                {
                    "container": str(container_port),
                    "host": str(binding.get("HostPort") or ""),
                    "ip": str(binding.get("HostIp") or ""),
                }
            )
    return rows


def container_summary(container):
    labels = dict(container.labels or {})
    managed, actions_allowed, protected = managed_flags(labels)
    image = getattr(getattr(container, "image", None), "tags", None) or []
    return {
        "container_id": container.id,
        "name": container.name,
        "image": image[0] if image else str((container.attrs or {}).get("Config", {}).get("Image") or ""),
        "status": str(container.status or "unknown"),
        "created_at": created_at(container),
        "managed_by_trion": managed,
        "actions_allowed": actions_allowed,
        "protected": protected,
    }


def resolve_container_reference(client, container_ref):
    try:
        return client.containers.get(container_ref)
    except Exception as exc:
        if is_not_found(exc):
            containers = client.containers.list(all=True)
            for item in containers:
                if str(getattr(item, "name", "") or "").strip() == str(container_ref or "").strip():
                    return item
        raise


def action_result(container, action):
    return {"ok": True, "action": action, "container": container_summary(container)}


def guard_managed_action(container):
    summary = container_summary(container)
    if not summary["managed_by_trion"]:
        return error_result("ACTION_NOT_ALLOWED", f"Container '{summary['name']}' is not managed by TRION")
    if summary["protected"]:
        return error_result("ACTION_NOT_ALLOWED", f"Container '{summary['name']}' is protected")
    if not summary["actions_allowed"]:
        return error_result("ACTION_NOT_ALLOWED", f"Actions are not allowed for container '{summary['name']}'")
    return None


def list_containers():
    try:
        client = get_docker_client()
        containers = client.containers.list(all=True)
        return {"containers": [container_summary(container) for container in containers]}
    except Exception as exc:
        return error_result("RUNTIME_UNAVAILABLE", str(exc), retryable=True)


def inspect_container(container_id):
    try:
        client = get_docker_client()
        container = resolve_container_reference(client, container_id)
        summary = container_summary(container)
        labels = dict(container.labels or {})
        manifest = read_home_manifest(container)
        return {
            "container": {
                **summary,
                "blueprint_id": blueprint_id_from_labels(labels),
                "labels": labels,
                "ports": port_rows(container),
                "mounts": [
                    f"{mount.get('Source', '?')}:{mount.get('Destination', '?')}"
                    for mount in (container.attrs or {}).get("Mounts", [])
                ],
                "runtime_state": dict((container.attrs or {}).get("State") or {}),
                "home_scope": build_home_scope(labels, manifest),
            }
        }
    except Exception as exc:
        if is_not_found(exc):
            return error_result("CONTAINER_NOT_FOUND", f"Container '{container_id}' not found")
        return error_result("RUNTIME_UNAVAILABLE", str(exc), retryable=True)


def get_container_logs(container_id, tail=200, since="", limit_chars=16000):
    safe_tail = max(1, min(int(tail), 500))
    safe_limit = max(256, min(int(limit_chars), 64000))
    try:
        client = get_docker_client()
        container = resolve_container_reference(client, container_id)
        raw = container.logs(tail=safe_tail, timestamps=True, since=since or None)
        logs = raw.decode("utf-8", errors="replace")
        truncated = len(logs) > safe_limit
        if truncated:
            logs = logs[-safe_limit:]
        return {
            "container_id": container_id,
            "logs": logs,
            "truncated": truncated,
            "tail": safe_tail,
            "since": str(since or ""),
            "limit_chars": safe_limit,
        }
    except Exception as exc:
        if is_not_found(exc):
            return error_result("CONTAINER_NOT_FOUND", f"Container '{container_id}' not found")
        return error_result("RUNTIME_UNAVAILABLE", str(exc), retryable=True)


def start_stopped_container(container_id):
    try:
        client = get_docker_client()
        container = resolve_container_reference(client, container_id)
        blocked = guard_managed_action(container)
        if blocked:
            return blocked
        container.reload()
        if str(container.status or "").strip().lower() == "running":
            return action_result(container, "already_running")
        container.start()
        container.reload()
        return action_result(container, "started")
    except Exception as exc:
        if is_not_found(exc):
            return error_result("CONTAINER_NOT_FOUND", f"Container '{container_id}' not found")
        return error_result("RUNTIME_UNAVAILABLE", str(exc), retryable=True)


def stop_container(container_id):
    try:
        client = get_docker_client()
        container = resolve_container_reference(client, container_id)
        blocked = guard_managed_action(container)
        if blocked:
            return blocked
        container.reload()
        if str(container.status or "").strip().lower() != "running":
            return action_result(container, "already_stopped")
        container.stop(timeout=10)
        container.reload()
        return action_result(container, "stopped")
    except Exception as exc:
        if is_not_found(exc):
            return error_result("CONTAINER_NOT_FOUND", f"Container '{container_id}' not found")
        return error_result("RUNTIME_UNAVAILABLE", str(exc), retryable=True)


def get_conn():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def load_json(row, key, default):
    try:
        return json.loads(row[key] or json.dumps(default))
    except Exception:
        return default


def row_version(row):
    updated = str(row["updated_at"] or "").strip()
    created = str(row["created_at"] or "").strip()
    return updated or created


def blueprint_definition(row):
    return {
        "id": row["id"],
        "name": row["name"],
        "description": row["description"] or "",
        "dockerfile": row["dockerfile"] or "",
        "image": row["image"] or "",
        "runtime": row["runtime"] or "",
        "ports": load_json(row, "ports_json", []),
        "mounts": load_json(row, "mounts_json", []),
        "environment": load_json(row, "environment_json", {}),
        "resources": load_json(row, "resources_json", {}),
        "tags": load_json(row, "tags_json", []),
        "icon": row["icon"] or "📦",
    }


def list_blueprints():
    try:
        conn = get_conn()
        rows = conn.execute(
            "SELECT id, name, description, created_at, updated_at FROM blueprints "
            "WHERE (is_deleted IS NULL OR is_deleted = 0) ORDER BY name"
        ).fetchall()
        conn.close()
        return {
            "blueprints": [
                {
                    "blueprint_id": row["id"],
                    "name": row["name"],
                    "description": row["description"] or "",
                    "version": row_version(row),
                }
                for row in rows
            ]
        }
    except sqlite3.OperationalError:
        return {"blueprints": []}


def get_blueprint(blueprint_id):
    try:
        conn = get_conn()
        row = conn.execute(
            "SELECT * FROM blueprints WHERE id = ? AND (is_deleted IS NULL OR is_deleted = 0)",
            (blueprint_id,),
        ).fetchone()
        conn.close()
        if not row:
            return error_result("BLUEPRINT_NOT_FOUND", f"Blueprint '{blueprint_id}' not found")
        return {
            "blueprint": {
                "blueprint_id": row["id"],
                "name": row["name"],
                "description": row["description"] or "",
                "version": row_version(row),
                "definition": blueprint_definition(row),
            }
        }
    except sqlite3.OperationalError:
        return error_result("RUNTIME_UNAVAILABLE", "Blueprint store is not initialized", retryable=True)


def handle_request(payload):
    method = payload.get("method", "")
    request_id = payload.get("id")
    params = payload.get("params") or {}

    if method == "initialize":
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "serverInfo": {"name": "container-commander", "version": "2.1.0"},
                "capabilities": {"tools": {"listChanged": False}},
            },
        }
    if method == "tools/list":
        return {"jsonrpc": "2.0", "id": request_id, "result": {"tools": TOOLS}}
    if method == "tools/call":
        name = ((params.get("name") or "").strip())
        arguments = (params.get("arguments") or {})
        if name == "container_list":
            result = list_containers()
        elif name == "container_inspect":
            result = inspect_container(str(arguments.get("container_id") or arguments.get("container_name") or ""))
        elif name == "container_logs":
            result = get_container_logs(
                str(arguments.get("container_id") or arguments.get("container_name") or ""),
                tail=arguments.get("tail", 200),
                since=str(arguments.get("since") or ""),
                limit_chars=arguments.get("limit_chars", 16000),
            )
        elif name == "blueprint_list":
            result = list_blueprints()
        elif name == "blueprint_get":
            result = get_blueprint(str(arguments.get("blueprint_id") or ""))
        elif name == "start_stopped_container":
            result = start_stopped_container(str(arguments.get("container_id") or arguments.get("container_name") or ""))
        elif name == "stop_container":
            result = stop_container(str(arguments.get("container_id") or arguments.get("container_name") or ""))
        else:
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {"code": -32601, "message": f"Unknown tool: {name}"},
            }
        return {"jsonrpc": "2.0", "id": request_id, "result": result}
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "error": {"code": -32601, "message": f"Method not found: {method}"},
    }


def main():
    while True:
        try:
            line = input()
        except EOFError:
            break
        if not line.strip():
            continue
        payload = json.loads(line)
        if payload.get("method") == "notifications/initialized":
            continue
        print(json.dumps(handle_request(payload)), flush=True)


if __name__ == "__main__":
    main()
